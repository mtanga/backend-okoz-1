<?php

namespace telesign\sdk\version;

const VERSION = "v3.0.0";
